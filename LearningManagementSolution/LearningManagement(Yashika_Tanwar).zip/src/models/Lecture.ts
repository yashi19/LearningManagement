
export interface LectureModel {
  id?:number;  
  name: string;
}

